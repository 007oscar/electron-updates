#ifndef __PENTERACT_RECOGNIZE_H__
#define __PENTERACT_RECOGNIZE_H__

#include <nan.h>

NAN_METHOD(Recognize);

#endif
