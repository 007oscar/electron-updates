#ifndef __PENTERACT_FROM_FILE_H__
#define __PENTERACT_FROM_FILE_H__

#include <nan.h>

NAN_METHOD(FromFile);

#endif
